import PDFDocument from 'pdfkit';
import type { Readable } from 'stream';

// Dados da Empresa
const COMPANY_INFO = {
  name: 'Adega Beira Rio',
  razaoSocial: 'Adega Beira Rio Comércio de Bebidas Ltda',
  cnpj: '50.887.052/0001-08',
  endereco: 'Rua Israel, 286, Rochdale',
  cidade: 'Osasco/SP',
  cep: '06220-053',
  logo: process.env.VITE_APP_LOGO || ''
};

export interface ReceivableCustomerData {
  customer: {
    id: number;
    name: string;
    email?: string | null;
    phone?: string | null;
    creditLimit?: string | number | null;
  };
  totalPending?: number | string;
  currentBalance?: string;
  sales: Array<{
    id: number;
    saleDate: Date | string;
    totalAmount: number | string;
    items: Array<{
      productName: string;
      quantity: number;
      unitPrice: number | string;
    }>;
  }>;
  payments?: Array<{
    paidDate: Date | string;
    paymentMethod: string;
    paidAmount: number | string;
  }>;
}

/**
 * Gera um PDF com o extrato de Contas a Receber para um cliente
 */
export function generateReceivablesPDF(data: ReceivableCustomerData): any {
  const doc = new PDFDocument({
    margin: 40,
    size: 'A4',
    bufferPages: true,
  });

  const pageWidth = doc.page.width;
  const pageHeight = doc.page.height;
  const margin = 40;
  const contentWidth = pageWidth - 2 * margin;

  // Cores da Empresa (Verde e Dourado)
  const primaryColor = '#2D5A3D'; // Verde escuro
  const accentColor = '#D4A574'; // Dourado
  const textColor = '#333333';
  const lightGray = '#F5F5F5';
  const borderColor = '#CCCCCC';
  const greenColor = '#27AE60';

  // Função auxiliar para formatar moeda
  const formatCurrency = (value: number | string): string => {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(numValue || 0);
  };

  // Função auxiliar para formatar data
  const formatDate = (date: Date | string): string => {
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleDateString('pt-BR');
  };

  // ===== CABEÇALHO COM DADOS DA EMPRESA =====
  // Header com cor da empresa
  doc.rect(0, 0, pageWidth, 100).fill(primaryColor);
  
  doc.fontSize(22).font('Helvetica-Bold').fillColor('white');
  doc.text('EXTRATO DE CONTAS A RECEBER', margin, 25, { align: 'center', width: contentWidth });

  doc.fontSize(10).font('Helvetica').fillColor('white');
  doc.text(COMPANY_INFO.razaoSocial, margin, 55, { align: 'center', width: contentWidth });
  doc.text(`CNPJ: ${COMPANY_INFO.cnpj}`, margin, 68, { align: 'center', width: contentWidth });
  doc.text(`${COMPANY_INFO.endereco} - ${COMPANY_INFO.cidade} - CEP: ${COMPANY_INFO.cep}`, margin, 81, { align: 'center', width: contentWidth });

  doc.y = 115;

  // ===== INFORMAÇÕES DO CLIENTE =====
  doc.fontSize(12).font('Helvetica-Bold').fillColor(primaryColor);
  doc.text('DADOS DO CLIENTE', margin, doc.y);

  doc.fontSize(10).font('Helvetica').fillColor(textColor);
  doc.text(`Nome: ${data.customer.name}`, margin, doc.y + 5);
  
  const creditLimit = data.customer.creditLimit 
    ? formatCurrency(data.customer.creditLimit)
    : 'Não definido';
  doc.text(`Limite de Crédito: ${creditLimit}`);

  doc.moveDown(0.5);

  // ===== RESUMO FINANCEIRO =====
  const summaryBoxY = doc.y + 5;
  const boxHeight = 60;
  const boxWidth = (contentWidth - 20) / 2;

  // Obter saldo devedor
  const saldoDevedor = data.currentBalance 
    ? parseFloat(data.currentBalance) 
    : (data.totalPending ? (typeof data.totalPending === 'string' ? parseFloat(data.totalPending) : data.totalPending) : 0);

  // Box 1: Saldo Devedor
  doc.rect(margin, summaryBoxY, boxWidth, boxHeight).fill(lightGray);
  doc.rect(margin, summaryBoxY, boxWidth, 4).fill(primaryColor); // Barra superior colorida
  doc.fontSize(9).font('Helvetica').fillColor(textColor);
  doc.text('SALDO DEVEDOR', margin + 10, summaryBoxY + 15);
  doc.fontSize(18).font('Helvetica-Bold').fillColor('#C0392B'); // Vermelho para valor devedor
  doc.text(formatCurrency(saldoDevedor), margin + 10, summaryBoxY + 32, { width: boxWidth - 20 });

  // Box 2: Data do Extrato
  doc.rect(margin + boxWidth + 20, summaryBoxY, boxWidth, boxHeight).fill(lightGray);
  doc.rect(margin + boxWidth + 20, summaryBoxY, boxWidth, 4).fill(accentColor); // Barra superior dourada
  doc.fontSize(9).font('Helvetica').fillColor(textColor);
  doc.text('DATA DO EXTRATO', margin + boxWidth + 30, summaryBoxY + 15);
  doc.fontSize(14).font('Helvetica-Bold').fillColor(primaryColor);
  doc.text(new Date().toLocaleDateString('pt-BR'), margin + boxWidth + 30, summaryBoxY + 35);

  doc.y = summaryBoxY + boxHeight + 20;

  // ===== TABELA DE VENDAS =====
  doc.fontSize(12).font('Helvetica-Bold').fillColor(primaryColor);
  doc.text('VENDAS A PRAZO', margin, doc.y);

  const tableTop = doc.y + 10;
  const tableMargin = margin;
  const col1Width = 60; // ID Venda
  const col2Width = 70; // Data
  const col3Width = 150; // Produto
  const col4Width = 50; // Qtd
  const col5Width = 75; // Valor Unit
  const col6Width = 80; // Total

  // Cabeçalho da tabela
  doc.rect(tableMargin, tableTop, contentWidth, 22).fill(primaryColor);
  doc.fontSize(9).font('Helvetica-Bold').fillColor('white');

  let colX = tableMargin + 5;
  doc.text('ID Venda', colX, tableTop + 6, { width: col1Width - 10 });
  colX += col1Width;
  doc.text('Data', colX, tableTop + 6, { width: col2Width - 10 });
  colX += col2Width;
  doc.text('Produto', colX, tableTop + 6, { width: col3Width - 10 });
  colX += col3Width;
  doc.text('Qtd', colX, tableTop + 6, { width: col4Width - 10, align: 'right' });
  colX += col4Width;
  doc.text('Valor Unit.', colX, tableTop + 6, { width: col5Width - 10, align: 'right' });
  colX += col5Width;
  doc.text('Total', colX, tableTop + 6, { width: col6Width - 10, align: 'right' });

  // Linhas da tabela
  let currentY = tableTop + 22;
  doc.fontSize(8).font('Helvetica').fillColor(textColor);

  if (data.sales && data.sales.length > 0) {
    let rowIndex = 0;
    data.sales.forEach((sale) => {
      const items = sale.items || [];
      
      if (items.length === 0) {
        // Venda sem itens detalhados
        if (rowIndex % 2 === 0) {
          doc.rect(tableMargin, currentY, contentWidth, 18).fill(lightGray);
        }
        
        colX = tableMargin + 5;
        doc.fillColor(textColor);
        doc.text(`#${sale.id}`, colX, currentY + 4, { width: col1Width - 10 });
        colX += col1Width;
        doc.text(formatDate(sale.saleDate), colX, currentY + 4, { width: col2Width - 10 });
        colX += col2Width;
        doc.text('Venda a prazo', colX, currentY + 4, { width: col3Width - 10 });
        colX += col3Width;
        doc.text('-', colX, currentY + 4, { width: col4Width - 10, align: 'right' });
        colX += col4Width;
        doc.text('-', colX, currentY + 4, { width: col5Width - 10, align: 'right' });
        colX += col5Width;
        doc.font('Helvetica-Bold');
        doc.text(formatCurrency(sale.totalAmount), colX, currentY + 4, { width: col6Width - 10, align: 'right' });
        doc.font('Helvetica');
        
        currentY += 18;
        rowIndex++;
      } else {
        // Venda com itens
        items.forEach((item, itemIdx) => {
          if (rowIndex % 2 === 0) {
            doc.rect(tableMargin, currentY, contentWidth, 18).fill(lightGray);
          }

          colX = tableMargin + 5;
          doc.fillColor(textColor);

          // ID Venda (apenas na primeira linha)
          if (itemIdx === 0) {
            doc.text(`#${sale.id}`, colX, currentY + 4, { width: col1Width - 10 });
          }
          colX += col1Width;

          // Data (apenas na primeira linha)
          if (itemIdx === 0) {
            doc.text(formatDate(sale.saleDate), colX, currentY + 4, { width: col2Width - 10 });
          }
          colX += col2Width;

          // Produto
          doc.text(item.productName || 'Produto', colX, currentY + 4, { width: col3Width - 10 });
          colX += col3Width;

          // Quantidade
          doc.text(item.quantity?.toString() || '1', colX, currentY + 4, { width: col4Width - 10, align: 'right' });
          colX += col4Width;

          // Valor Unitário
          doc.text(formatCurrency(item.unitPrice || 0), colX, currentY + 4, { width: col5Width - 10, align: 'right' });
          colX += col5Width;

          // Total (apenas na primeira linha)
          if (itemIdx === 0) {
            doc.font('Helvetica-Bold');
            doc.text(formatCurrency(sale.totalAmount), colX, currentY + 4, { width: col6Width - 10, align: 'right' });
            doc.font('Helvetica');
          }

          currentY += 18;
          rowIndex++;
        });
      }

      // Linha divisória após cada venda
      doc.moveTo(tableMargin, currentY).lineTo(tableMargin + contentWidth, currentY).stroke(borderColor);
    });
  } else {
    // Sem vendas
    doc.rect(tableMargin, currentY, contentWidth, 30).fill(lightGray);
    doc.fontSize(10).fillColor('#999999');
    doc.text('Nenhuma venda a prazo registrada', tableMargin, currentY + 10, { width: contentWidth, align: 'center' });
    currentY += 30;
  }

  doc.y = currentY + 15;

  // ===== HISTÓRICO DE RECEBIMENTOS =====
  if (data.payments && data.payments.length > 0) {
    doc.fontSize(12).font('Helvetica-Bold').fillColor(primaryColor);
    doc.text('HISTÓRICO DE RECEBIMENTOS', margin, doc.y);

    const paymentTableTop = doc.y + 10;
    const payCol1Width = 120; // Data
    const payCol2Width = 180; // Forma de Pagamento
    const payCol3Width = 120; // Valor

    // Cabeçalho
    doc.rect(tableMargin, paymentTableTop, contentWidth, 22).fill(greenColor);
    doc.fontSize(9).font('Helvetica-Bold').fillColor('white');

    colX = tableMargin + 5;
    doc.text('Data Recebimento', colX, paymentTableTop + 6, { width: payCol1Width - 10 });
    colX += payCol1Width;
    doc.text('Forma de Pagamento', colX, paymentTableTop + 6, { width: payCol2Width - 10 });
    colX += payCol2Width;
    doc.text('Valor Recebido', colX, paymentTableTop + 6, { width: payCol3Width - 10, align: 'right' });

    // Linhas
    let paymentY = paymentTableTop + 22;
    doc.fontSize(8).font('Helvetica').fillColor(textColor);

    data.payments.forEach((payment, idx) => {
      if (idx % 2 === 0) {
        doc.rect(tableMargin, paymentY, contentWidth, 18).fill(lightGray);
      }

      colX = tableMargin + 5;
      doc.fillColor(textColor);
      doc.text(formatDate(payment.paidDate), colX, paymentY + 4, { width: payCol1Width - 10 });
      colX += payCol1Width;
      doc.text(payment.paymentMethod || 'Não informado', colX, paymentY + 4, { width: payCol2Width - 10 });
      colX += payCol2Width;
      doc.font('Helvetica-Bold').fillColor(greenColor);
      doc.text(formatCurrency(payment.paidAmount), colX, paymentY + 4, { width: payCol3Width - 10, align: 'right' });
      doc.font('Helvetica').fillColor(textColor);

      paymentY += 18;
    });

    doc.moveTo(tableMargin, paymentY).lineTo(tableMargin + contentWidth, paymentY).stroke(borderColor);
  }

  // ===== RODAPÉ =====
  doc.fontSize(8).fillColor('#666666');
  doc.text(
    `Este documento é uma cópia do extrato de Contas a Receber.`,
    margin, pageHeight - 55,
    { width: contentWidth, align: 'center' }
  );
  doc.text(
    `${COMPANY_INFO.razaoSocial} - CNPJ: ${COMPANY_INFO.cnpj}`,
    margin, pageHeight - 42,
    { width: contentWidth, align: 'center' }
  );
  doc.text(
    `${COMPANY_INFO.endereco} - ${COMPANY_INFO.cidade} - CEP: ${COMPANY_INFO.cep}`,
    margin, pageHeight - 30,
    { width: contentWidth, align: 'center' }
  );

  doc.end();

  return doc as any;
}
